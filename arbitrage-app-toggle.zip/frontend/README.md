Frontend: Vite app with Network Toggle. Set VITE_* env vars in Vercel.
