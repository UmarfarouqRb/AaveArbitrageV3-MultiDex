const { ethers } = require('hardhat');
async function main() {
  const [deployer] = await ethers.getSigners();
  console.log('Deploying with', deployer.address);
  const Arb = await ethers.getContractFactory('ArbitrageBalancer');
  const arb = await Arb.deploy(deployer.address);
  await arb.deployed();
  console.log('ArbitrageBalancer deployed to', arb.address);
  const fs = require('fs');
  fs.writeFileSync('deployed-address.txt', arb.address);
}
main().catch(e=>{ console.error(e); process.exit(1); });
