Contracts: configure .env for mainnet and sepolia then deploy.
