Backend: reads NETWORK env and uses appropriate RPC/contract.
