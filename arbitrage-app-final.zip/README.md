# Arbitrage App (Toggle-ready)
This package adds a network toggle (Base mainnet / Base Sepolia) to the existing app.
