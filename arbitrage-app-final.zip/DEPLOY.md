Follow contracts/README.md and backend/README.md. Set envs for both networks in Vercel/GitHub.
